#include "wataninput.h"

WatanInput::~WatanInput() {}
